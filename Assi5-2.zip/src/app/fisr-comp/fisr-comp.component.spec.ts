import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FisrCompComponent } from './fisr-comp.component';

describe('FisrCompComponent', () => {
  let component: FisrCompComponent;
  let fixture: ComponentFixture<FisrCompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FisrCompComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FisrCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
